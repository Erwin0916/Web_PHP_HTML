	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="stylesheet.css?ver=1">
		<title>Document</title>
	</head>
	<body>
		<header>
    	<?php include "header.php";?>
    	</header>
		
			<!-- ----------------------몸통-------------------------------- -->
			<div class="content">
				<div class="banner">
					<div class="slidebox">
						<input type="radio" name="slide" id="slide01" checked>
						<input type="radio" name="slide" id="slide02">
						<input type="radio" name="slide" id="slide03">
						<input type="radio" name="slide" id="slide04">
						<div class="slidelist">
							<li class="slideitem">
								<a><img src="./img/banner_04.png"></a>
							</li>
							<li class="slideitem">
								<a><img src="./img/banner_01.jpg"></a>
							</li>
							<li class="slideitem">
								<a><img src="./img/banner_02.jpg"></a>
							</li>
							<li class="slideitem">
								<a><img src="./img/banner_03.jpg"></a>
							</li>
							
						</div>
						<div class="slide-control">
							<div class="control01">
								<label for="slide04" class="prev"></label>
								<label for="slide02" class="next"></label>
							</div>
							<div class="control02">
								<label for="slide01" class="prev"></label>
								<label for="slide03" class="next"></label>
							</div>
							<div class="control03">
								<label for="slide02" class="prev"></label>
								<label for="slide04" class="next"></label>
							</div>
							<div class="control04">
								<label for="slide03" class="prev"></label>
								<label for="slide01" class="next"></label>
							</div>
						</div>
					</div>
				</div>
				<div class="cons">
					<div class="con1_left"><img src="./img/product_05.jpg"></div>
					<div class="con1_right">속이 꽉찬 고기만두</div>
					<div class="con2_left"><img src="./img/product_02.jpg"></div>
					<div class="con2_right">숯불 곱창볶음</div>
					<div class="con3_left"><img src="./img/product_03.jpg"></div>
					<div class="con3_right">얼큰한 뼈해장국</div>
					<div class="con4_left"><img src="./img/product_04.jpg"></div>
					<div class="con4_right">해물 볶음밥(3가지 맛)</div>
				</div>
			

			<!-- ----------------------푸터-------------------------------- -->

		</div>
		<footer>
    	<?php include "footer.php";?>
    	</footer>


	</body>
	</html>