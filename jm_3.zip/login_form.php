<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title>PHP 프로그래밍 입문</title>
<script type="text/javascript" src="./js/login.js"></script>
<link rel="stylesheet" href="form.css">
</head>
<body> 
	<header>
    	<?php include "header.php";?>
    </header>
	<section>
		<!--<div id="main_img_bar">
            <img src="./img/main_img.png">
        </div>-->
        <div id="login">
      		<div id="login_box">
	    		<div id="login_title">
		    		<h2>로그인</h2>
	    		</div>
	    		<div id="login_form">
          		<form  name="login_form" method="post" action="login.php">		       	
                  	
                    <input type="text" name="id" placeholder="아이디" >
                    <br>
                    <input type="password" id="pass" name="pass" placeholder="비밀번호" >
                    <br>
                    <input type=submit >
                  	<!--</ul>
                  	<div id="login_btn">
                      	<a href="login.php"><img src="./img/login.png" onclick="check_input()"></a>
                  	</div>-->		    	
           		</form>
        		</div> <!-- login_form -->
    		</div> <!-- login_box -->
        </div> <!-- main_content -->
	</section> 
	<footer>
    	<?php include "footer.php";?>
    </footer>
</body>

</html>

