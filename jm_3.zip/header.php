<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="stylesheet.css">
		<link rel="stylesheet" href="common.css?ver=1">

	<title>Document</title>
</head>
<body>	
	
<?php
    session_start();
    if (isset($_SESSION["userid"])) $userid = $_SESSION["userid"];
    else $userid = "";
    if (isset($_SESSION["username"])) $username = $_SESSION["username"];
    else $username = "";
    if (isset($_SESSION["userlevel"])) $userlevel = $_SESSION["userlevel"];
    else $userlevel = "";
    if (isset($_SESSION["userpoint"])) $userpoint = $_SESSION["userpoint"];
    else $userpoint = "";
?>	
           
		<div class="header">
			<div class="h_color">색</div>
			<div class="h_top">
				<div class="h_logo"><a href="main.php"><img src="img/logo.png" alt=""></a></div>
				<div class="h_search">
					<form action="#">
						<input type="text">
					</form>
				</div>
				<div class="h_sign">
					<div class="s_top">
						<?php
    						if(!$userid) {
						?>    
						
						<div class="s_t_left"><a href="login_form.php"><input type="button" value="로그인"></a></div>
						<div class="s_t_right"><a href="member_form.php"><input type="button" value="회원가입"></a></div>
						<?php
    						}	else {
                						$logged = $username."(".$userid.")님[Level:".$userlevel.", Point:".$userpoint."]";
						?>
						<ul><li><?=$logged?></li></ul>
						<div class="s_t_left"><a href="logout.php"><input type="button" value="로그아웃"></a></div>
						<div class="s_t_right"><a href="member_modify_form.php"><input type="button" value="정보 수정"></a></div>

						<?php
    						}
						?>
					</div>
					<div class="s_bot">
						<div class="s_b_left"><a href="#"><input type="button" value="장바구니"></a></div>
						<div class="s_b_right"><a href="#"><input type="button" value="마이페이지"></a></div>
					</div>

				</div>
			</div>
			<div class="h_bot">
					<div class="b_left">
						<div class="dropdown">
							<button class="dropbtn">드롭다운 메뉴</button>
							<div class="dropdown-content">
								<a href="#">홈</a>
								<a href="#">회사소개</a>
								<a href="#">제품소개</a>
								<a href="#">오시는길</a>
							</div>
						</div>
					</div>
					<div class="b_right">
						<ul>
							<li><a href="board_list.php">게시판</a></li>
							<li><a href="event.php">이벤트</a></li>
							<li><a href="#">인기베스트</a></li>
						</ul>

					</div>
				</div>
		</div>

</body>
</html>