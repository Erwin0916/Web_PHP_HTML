<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="stylesheet_evdt.css?ver=1">
	<title>Document</title>
</head>
<body>
	
	<div class="main">
<!-- ----------------------해더-------------------------------- -->
			<div class="header">
				<div class="h_color">색</div>
				<div class="h_top">
					<div class="h_logo"><a href="main.php"><img src="img/logo.png" alt=""></a></div>
					<div class="h_search">
						<form action="#">
							<input type="text">
						</form>
					</div>
					<div class="h_sign">
						<div class="s_top">
							<div class="s_t_left"><a href="#"><input type="button" value="로그인"></a></div>
							<div class="s_t_right"><a href="#"><input type="button" value="회원가입"></a></div>
						</div>
						<div class="s_bot">
							<div class="s_b_left"><a href="#"><input type="button" value="장바구니"></a></div>
							<div class="s_b_right"><a href="#"><input type="button" value="마이페이지"></a></div>
						</div>

					</div>
				</div>
				<div class="h_bot">
					<div class="b_left">
						<div class="dropdown">
							<button class="dropbtn">드롭다운 메뉴</button>
							<div class="dropdown-content">
								<a href="#">홈</a>
								<a href="#">회사소개</a>
								<a href="#">제품소개</a>
								<a href="#">오시는길</a>
							</div>
						</div>
					</div>
					<div class="b_right">
						<ul>
							<li><a href="board.php">게시판</a></li>
							<li><a href="event.php">이벤트</a></li>
							<li><a href="#">인기베스트</a></li>
						</ul>

					</div>
				</div>
			</div>
<!-- ----------------------몸통-------------------------------- -->
		
		<div class="content">
			이벤트디테일@@@@@@@@@@@@@@@@@@@@@@@@@@
		</div>

<!-- ----------------------푸터-------------------------------- -->
		<div class="footer">
			<div class="footer_L"><img src="img/logo.png" alt=""></div>

			<div class="footer_R">오른쪽</div>

		</div>
		

	</div>



</body>
</html>