<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="stylesheet_ev.css?ver=1">
		<link rel="stylesheet" href="common.css?ver=1">
	<title>Document</title>
</head>
<body>
	<header>
    	<?php include "header.php";?>
    </header>

<!-- ----------------------몸통-------------------------------- -->
		<div class="content">
			<a href="event_detail.php">이벤트 입니다</a>
		</div>

	<footer>
    	<?php include "footer.php";?>
    </footer>



</body>
</html>