<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="footer.css">
	<title>Document</title>
</head>
<body>

<!-- ----------------------푸터-------------------------------- -->
		<div class="footer">
			<nav>
        
    	</nav>
    	<p>
    		<br><br>
        	<span>대표 : 박진명</span><br/>
        	<span>이메일 : jin@gmail.com</span><br/>
        	<span>Copyright 2020. CheFrozen. All Rights Reserved.</span>
    	</p>

			<!--<div class="footer_L"><img src="img/logo.png" alt=""></div>-->
		</div>
		

	



</body>
</html>